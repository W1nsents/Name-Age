﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;

namespace ConsoleApp1
{
    internal class Program
    {
        //Переменные
        public static string Name = null;
        public static string ReallyName = "";
        public static int Age = 0x00;

        //Главная
        static void Main(string[] args)
        {

            //Название консоли
            Console.Title = "Тест";

            //Начало
            NameString();

        }

        //Возраст
        public static void AgeNumber()
        {
            //Обработка исключений
            try
            {
                //Ввод
                Console.Write("Введи тут свой возраст, петуш: ");
                Age = Int32.Parse(Console.ReadLine());
                //Если цифра меньше или равна 13
                if (Age <= 13)
                {
                    Console.WriteLine($"Пашол нахуй, тебе не может быть {Age} лет..");
                    Thread.Sleep(1500);
                    Environment.Exit(0);
                }
                //Если больше 13 то пропускаем
                else
                {
                    Conclusion();
                }
            }
            //Если в INT есть буквы
            catch
            {
                Console.WriteLine("Какие нахуй буквы в возрасте, ебланитос в стиле читос.");
                AgeNumber();
            }

        }

        //Имя
        public static void NameString()
        {
            //Ввод
            Console.Write("Ебать ты клоун, накалякай сюда своё имя: ");
            Name = Console.ReadLine();
            AgeNumber();

        }

        

        //Ответ
        public static void Conclusion()
        {
            //Если есть цифры, то убираем их нахуй
            for (int i = 0; i < Name.Length; i++)
            {
                if (!char.IsDigit(Name[i]))
                {
                    //Выставление реального имени без цифр
                    ReallyName += Name[i];
                }
            }

            //Если реальное имя пустое, то идёшь нахуй
            if (ReallyName == "")
            {
                Console.WriteLine("Пашол нахуй, человек без имени блять..");
                Thread.Sleep(1500);
                Environment.Exit(0);

            }
            //В противном случае выдаём результаты
            else
            {
                Console.WriteLine($"Твоё имя: {ReallyName}\nТвой возраст: {Age}");
                Thread.Sleep(1500);
                if (ReallyName == "Димон")
                {
                    if(Age == 17)
                    {
                        Console.WriteLine("Ебать кто пожаловал :D");
                        Console.ReadLine();
                    }
                }
                Console.ReadLine();
            }

        }
    }
}
